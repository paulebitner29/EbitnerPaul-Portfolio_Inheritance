
public class paulEbitner {
	// initiate variables.
	String Age = "19";
	String Birthday = "September 29, 2003";
	String Facebook = "Paul Christian Ebuenga Ebitner";
	String Contact = "09513186682";
	String Email = "ebitnerpaul@gmail.com";
	String Address = "Manila, Sta. Mesa";
	String Gender = "Male";
	String Religion = "Baptist";
	String Instagram = "pl.btnr";
	
	
}
