 

public class Talents_Achievements extends Hobbies{
	//initialize variables.
	String SHSGraduated = "Senior High School Graduated";
	String PlayingInstruments = "Playing Musical Instruments";
}
