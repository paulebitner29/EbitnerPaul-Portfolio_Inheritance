

public class Education extends Course {
	//initialize variables.
	String TertiarySchool = "National University";
	String TertiaryYear = "2022 - Present";
	String SecondarySchool = "Pamibian Integrated School";
	String SecondaryYear = "2021 - 2022";
	String PrimarySchool = "Candelaria Central Elementary School";
	String PrimaryYear = "2015 - 2016";

}
