

public class Course extends Talents_Achievements {
	//initiate variables 
	String WhyCourse = "     First of all, because it was in demand. And then, I want to \r\ngain more knowledge about technologies. I want to earn a lot \r\nof money to have great life in the future. Nowadays, Information\r\ntechnology is one of the best courses to earn your own money. \r\nThis course can help me to achieve my dream life. That's why I\r\npursue this course.\r\n";
	String WhatCourse = "     Information technology is the process of creating\r\ncommunication networks for a business, protectingdata\r\nand information, managing databases, assisting staff in\r\ntroubleshooting computer or mobile device issues, or\r\nperforming a variety of other tasks to guaranteethe\r\neffectiveness and security of business information systems.";
}
