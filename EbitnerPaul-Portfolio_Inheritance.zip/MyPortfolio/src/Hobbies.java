

public class Hobbies extends paulEbitner{
	//initiate variables
	String MusicalInstrument = "Playing Musical Instuments";
	String Basketball = "Basketball";
	String Cycling = "Cycling";
	String Watching = "Watching"; 
	
}
